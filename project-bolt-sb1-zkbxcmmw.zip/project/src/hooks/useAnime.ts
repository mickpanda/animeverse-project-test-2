import { useState, useEffect } from 'react';
import { animeApi, Anime, AnimeSearchResult } from '../lib/api';

export const useAnimeSearch = (initialQuery: string = '') => {
  const [data, setData] = useState<AnimeSearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = async (params: {
    query?: string;
    page?: number;
    limit?: number;
    type?: string;
    status?: string;
    genre?: string;
  }) => {
    setLoading(true);
    setError(null);

    try {
      const result = await animeApi.search(params);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Search failed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      search({ query: initialQuery });
    }
  }, [initialQuery]);

  return { data, loading, error, search };
};

export const useAnimeDetails = (malId: number | null) => {
  const [data, setData] = useState<Anime | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!malId) return;

    const fetchDetails = async () => {
      setLoading(true);
      setError(null);

      try {
        const anime = await animeApi.getDetails(malId);
        setData(anime);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch anime details');
      } finally {
        setLoading(false);
      }
    };

    fetchDetails();
  }, [malId]);

  return { data, loading, error };
};

export const useSeasonalAnime = (year?: number, season?: string) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSeasonal = async (params: {
    year?: number;
    season?: string;
    page?: number;
  } = {}) => {
    setLoading(true);
    setError(null);

    try {
      const result = await animeApi.getSeasonal(params);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch seasonal anime');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSeasonal({ year, season });
  }, [year, season]);

  return { data, loading, error, fetchSeasonal };
};

export const useTrendingAnime = () => {
  const [data, setData] = useState<AnimeSearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTrending = async () => {
      setLoading(true);
      setError(null);

      try {
        const result = await animeApi.getTrending();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch trending anime');
      } finally {
        setLoading(false);
      }
    };

    fetchTrending();
  }, []);

  return { data, loading, error };
};