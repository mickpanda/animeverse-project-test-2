import React from 'react';
import { Star, Calendar, Users, Play } from 'lucide-react';
import { Anime } from '../lib/api';

interface AnimeCardProps {
  anime: Anime;
  onClick?: () => void;
  showAddToWatchlist?: boolean;
  onAddToWatchlist?: () => void;
}

export const AnimeCard: React.FC<AnimeCardProps> = ({ 
  anime, 
  onClick, 
  showAddToWatchlist = false,
  onAddToWatchlist
}) => {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'currently airing':
      case 'airing':
        return 'bg-green-100 text-green-800';
      case 'finished airing':
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'not yet aired':
      case 'upcoming':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'TBA';
    return new Date(dateString).getFullYear();
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer group overflow-hidden"
      onClick={onClick}
    >
      <div className="relative overflow-hidden">
        <img
          src={anime.image}
          alt={anime.title}
          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            e.currentTarget.src = 'https://via.placeholder.com/300x400?text=No+Image';
          }}
        />
        
        {/* Status Badge */}
        <div className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(anime.status)}`}>
          {anime.status}
        </div>

        {/* Score Badge */}
        {anime.score && (
          <div className="absolute top-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded-full flex items-center gap-1">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
            <span className="text-xs font-medium">{anime.score}</span>
          </div>
        )}

        {/* Add to Watchlist Button */}
        {showAddToWatchlist && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToWatchlist?.();
            }}
            className="absolute bottom-2 right-2 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0"
          >
            <Play className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
          {anime.titleEnglish || anime.title}
        </h3>

        {anime.title !== anime.titleEnglish && anime.titleEnglish && (
          <p className="text-sm text-gray-600 mb-2 line-clamp-1">{anime.title}</p>
        )}

        {anime.synopsis && (
          <p className="text-sm text-gray-700 mb-3 line-clamp-3">
            {anime.synopsis}
          </p>
        )}

        <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            <span>{formatDate(anime.airedFrom)}</span>
          </div>
          
          {anime.episodes && (
            <div className="flex items-center gap-1">
              <Play className="w-3 h-3" />
              <span>{anime.episodes} eps</span>
            </div>
          )}
        </div>

        {anime.genres && anime.genres.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {anime.genres.slice(0, 3).map((genre, index) => (
              <span
                key={index}
                className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs"
              >
                {genre}
              </span>
            ))}
            {anime.genres.length > 3 && (
              <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                +{anime.genres.length - 3}
              </span>
            )}
          </div>
        )}

        {anime.studios && anime.studios.length > 0 && (
          <div className="mt-2 text-xs text-gray-500">
            <span className="font-medium">Studio:</span> {anime.studios[0]}
          </div>
        )}
      </div>
    </div>
  );
};