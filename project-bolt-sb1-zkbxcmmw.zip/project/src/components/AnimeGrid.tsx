import React from 'react';
import { AnimeCard } from './AnimeCard';
import { Anime } from '../lib/api';

interface AnimeGridProps {
  anime: Anime[];
  loading?: boolean;
  onAnimeClick?: (anime: Anime) => void;
  showAddToWatchlist?: boolean;
  onAddToWatchlist?: (anime: Anime) => void;
}

export const AnimeGrid: React.FC<AnimeGridProps> = ({
  anime,
  loading = false,
  onAnimeClick,
  showAddToWatchlist = false,
  onAddToWatchlist,
}) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {Array.from({ length: 10 }).map((_, index) => (
          <div key={index} className="animate-pulse">
            <div className="bg-gray-300 rounded-xl h-64 w-full mb-4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-300 rounded w-3/4"></div>
              <div className="h-3 bg-gray-300 rounded w-1/2"></div>
              <div className="h-3 bg-gray-300 rounded w-full"></div>
              <div className="h-3 bg-gray-300 rounded w-2/3"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (anime.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-500 text-lg">No anime found</div>
        <p className="text-gray-400 mt-2">Try adjusting your search or filters</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
      {anime.map((item) => (
        <AnimeCard
          key={item.malId}
          anime={item}
          onClick={() => onAnimeClick?.(item)}
          showAddToWatchlist={showAddToWatchlist}
          onAddToWatchlist={() => onAddToWatchlist?.(item)}
        />
      ))}
    </div>
  );
};