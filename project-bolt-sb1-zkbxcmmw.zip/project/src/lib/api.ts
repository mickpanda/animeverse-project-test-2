import { supabase } from './supabase';

const API_BASE_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1`;

// Anime API interfaces
export interface Anime {
  id: number;
  malId: number;
  title: string;
  titleEnglish?: string;
  synopsis?: string;
  image: string;
  score?: number;
  episodes?: number;
  status: string;
  airedFrom?: string;
  airedTo?: string;
  genres: string[];
  studios: string[];
  rank?: number;
  popularity?: number;
  source?: string;
  duration?: string;
  rating?: string;
  year?: number;
  season?: string;
}

export interface AnimeSearchResult {
  anime: Anime[];
  pagination: {
    currentPage: number;
    hasNextPage: boolean;
    lastPage: number;
    total: number;
  };
}

export interface SeasonalAnimeResult {
  anime: Anime[];
  pagination: {
    currentPage: number;
    hasNextPage: boolean;
    lastPage: number;
  };
  season: {
    year: number;
    season: string;
  };
}

// Auth headers for API calls
const getAuthHeaders = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return {
    'Authorization': `Bearer ${session?.access_token || import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
  };
};

// Anime API functions
export const animeApi = {
  // Search anime
  search: async (params: {
    query?: string;
    page?: number;
    limit?: number;
    type?: string;
    status?: string;
    genre?: string;
  }): Promise<AnimeSearchResult> => {
    const searchParams = new URLSearchParams();
    
    if (params.query) searchParams.set('q', params.query);
    if (params.page) searchParams.set('page', params.page.toString());
    if (params.limit) searchParams.set('limit', params.limit.toString());
    if (params.type) searchParams.set('type', params.type);
    if (params.status) searchParams.set('status', params.status);
    if (params.genre) searchParams.set('genre', params.genre);

    const response = await fetch(`${API_BASE_URL}/anime-search?${searchParams}`, {
      headers: await getAuthHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Search failed: ${response.statusText}`);
    }

    return response.json();
  },

  // Get anime details
  getDetails: async (malId: number): Promise<Anime> => {
    const response = await fetch(`${API_BASE_URL}/anime-details?mal_id=${malId}`, {
      headers: await getAuthHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch anime details: ${response.statusText}`);
    }

    return response.json();
  },

  // Get seasonal anime
  getSeasonal: async (params: {
    year?: number;
    season?: string;
    page?: number;
  } = {}): Promise<SeasonalAnimeResult> => {
    const searchParams = new URLSearchParams();
    
    if (params.year) searchParams.set('year', params.year.toString());
    if (params.season) searchParams.set('season', params.season);
    if (params.page) searchParams.set('page', params.page.toString());

    const response = await fetch(`${API_BASE_URL}/anime-seasonal?${searchParams}`, {
      headers: await getAuthHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch seasonal anime: ${response.statusText}`);
    }

    return response.json();
  },

  // Get trending anime (current season, sorted by popularity)
  getTrending: async (): Promise<AnimeSearchResult> => {
    return animeApi.search({
      type: 'tv',
      status: 'airing',
      limit: 20,
    });
  },
};

// Watchlist API functions
export const watchlistApi = {
  // Get user's watchlist
  getWatchlist: async (userId: string) => {
    const { data, error } = await supabase
      .from('user_watchlist')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Add anime to watchlist
  addToWatchlist: async (animeData: {
    anime_mal_id: number;
    status?: string;
    rating?: number;
    episodes_watched?: number;
    notes?: string;
  }) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('user_watchlist')
      .insert({
        user_id: user.id,
        ...animeData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Update watchlist item
  updateWatchlist: async (id: string, updates: {
    status?: string;
    rating?: number;
    episodes_watched?: number;
    notes?: string;
  }) => {
    const { data, error } = await supabase
      .from('user_watchlist')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Remove from watchlist
  removeFromWatchlist: async (id: string) => {
    const { error } = await supabase
      .from('user_watchlist')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },
};

// Reviews API functions
export const reviewsApi = {
  // Get reviews for an anime
  getAnimeReviews: async (malId: number) => {
    const { data, error } = await supabase
      .from('user_reviews')
      .select(`
        *,
        user_profiles (
          username,
          avatar_url
        )
      `)
      .eq('anime_mal_id', malId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Add a review
  addReview: async (reviewData: {
    anime_mal_id: number;
    rating: number;
    review_text: string;
    is_spoiler?: boolean;
  }) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('user_reviews')
      .insert({
        user_id: user.id,
        ...reviewData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Update a review
  updateReview: async (id: string, updates: {
    rating?: number;
    review_text?: string;
    is_spoiler?: boolean;
  }) => {
    const { data, error } = await supabase
      .from('user_reviews')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },
};

// Authentication functions
export const authApi = {
  // Sign up
  signUp: async (email: string, password: string, username: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;

    // Create user profile
    if (data.user) {
      const { error: profileError } = await supabase
        .from('user_profiles')
        .insert({
          id: data.user.id,
          username,
        });

      if (profileError) throw profileError;
    }

    return data;
  },

  // Sign in
  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
    return data;
  },

  // Sign out
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  // Get current user
  getCurrentUser: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  },
};