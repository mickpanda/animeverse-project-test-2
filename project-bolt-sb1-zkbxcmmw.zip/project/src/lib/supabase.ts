import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          username: string;
          avatar_url?: string;
          bio?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          username: string;
          avatar_url?: string;
          bio?: string;
        };
        Update: {
          username?: string;
          avatar_url?: string;
          bio?: string;
        };
      };
      user_watchlist: {
        Row: {
          id: string;
          user_id: string;
          anime_mal_id: number;
          status: 'watching' | 'completed' | 'plan_to_watch' | 'dropped' | 'on_hold';
          rating?: number;
          episodes_watched: number;
          notes?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          anime_mal_id: number;
          status?: 'watching' | 'completed' | 'plan_to_watch' | 'dropped' | 'on_hold';
          rating?: number;
          episodes_watched?: number;
          notes?: string;
        };
        Update: {
          status?: 'watching' | 'completed' | 'plan_to_watch' | 'dropped' | 'on_hold';
          rating?: number;
          episodes_watched?: number;
          notes?: string;
        };
      };
      user_reviews: {
        Row: {
          id: string;
          user_id: string;
          anime_mal_id: number;
          rating: number;
          review_text: string;
          is_spoiler: boolean;
          helpful_count: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          anime_mal_id: number;
          rating: number;
          review_text: string;
          is_spoiler?: boolean;
        };
        Update: {
          rating?: number;
          review_text?: string;
          is_spoiler?: boolean;
        };
      };
      forum_posts: {
        Row: {
          id: string;
          user_id: string;
          anime_mal_id?: number;
          title: string;
          content: string;
          category: string;
          reply_count: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          anime_mal_id?: number;
          title: string;
          content: string;
          category?: string;
        };
        Update: {
          title?: string;
          content?: string;
          category?: string;
        };
      };
    };
  };
}