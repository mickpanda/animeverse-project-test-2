import React, { useState, useEffect } from 'react';
import { Search, TrendingUp, Calendar, User, Menu, X } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { AnimeGrid } from './components/AnimeGrid';
import { LoadingSpinner } from './components/LoadingSpinner';
import { useAnimeSearch, useSeasonalAnime, useTrendingAnime } from './hooks/useAnime';
import { Anime } from './lib/api';
import { supabase } from './lib/supabase';

type Tab = 'discover' | 'trending' | 'seasonal' | 'watchlist';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('discover');
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [user, setUser] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Hooks for different data sources
  const { data: searchData, loading: searchLoading, search } = useAnimeSearch();
  const { data: trendingData, loading: trendingLoading } = useTrendingAnime();
  const { data: seasonalData, loading: seasonalLoading } = useSeasonalAnime();

  useEffect(() => {
    // Get initial user
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSearch = (query: string, filters?: any) => {
    search({ query, ...filters });
    setActiveTab('discover');
  };

  const handleAnimeClick = (anime: Anime) => {
    setSelectedAnime(anime);
  };

  const getCurrentData = () => {
    switch (activeTab) {
      case 'trending':
        return trendingData;
      case 'seasonal':
        return seasonalData;
      case 'discover':
      default:
        return searchData;
    }
  };

  const getCurrentLoading = () => {
    switch (activeTab) {
      case 'trending':
        return trendingLoading;
      case 'seasonal':
        return seasonalLoading;
      case 'discover':
      default:
        return searchLoading;
    }
  };

  const tabs = [
    { id: 'discover' as Tab, label: 'Discover', icon: Search },
    { id: 'trending' as Tab, label: 'Trending', icon: TrendingUp },
    { id: 'seasonal' as Tab, label: 'Seasonal', icon: Calendar },
    { id: 'watchlist' as Tab, label: 'Watchlist', icon: User },
  ];

  const currentData = getCurrentData();
  const isLoading = getCurrentLoading();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AniTracker
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2 rounded-lg text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <button
                  onClick={() => supabase.auth.signOut()}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Sign Out
                </button>
              ) : (
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Sign In
                </button>
              )}
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t bg-white">
              <nav className="py-4 space-y-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-3 text-left rounded-lg transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-100 text-blue-700'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Bar */}
        <div className="mb-8">
          <SearchBar
            onSearch={handleSearch}
            placeholder="Search for anime..."
            showFilters={true}
          />
        </div>

        {/* Page Title */}
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-gray-900 capitalize">
            {activeTab === 'discover' && !currentData ? 'Discover Anime' : 
             activeTab === 'trending' ? 'Trending Now' :
             activeTab === 'seasonal' ? 'This Season' :
             activeTab === 'watchlist' ? 'My Watchlist' :
             'Search Results'}
          </h2>
          {currentData && (
            <p className="text-gray-600 mt-1">
              {currentData.anime?.length || 0} anime found
            </p>
          )}
        </div>

        {/* Content */}
        {activeTab === 'watchlist' && !user ? (
          <div className="text-center py-12">
            <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Sign in to view your watchlist</h3>
            <p className="text-gray-600 mb-6">Keep track of what you're watching and discover new anime</p>
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Sign In
            </button>
          </div>
        ) : (
          <>
            {isLoading ? (
              <div className="flex justify-center py-12">
                <LoadingSpinner size="lg" />
              </div>
            ) : currentData?.anime ? (
              <AnimeGrid
                anime={currentData.anime}
                onAnimeClick={handleAnimeClick}
                showAddToWatchlist={!!user}
              />
            ) : activeTab === 'discover' ? (
              <div className="text-center py-12">
                <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Search for anime</h3>
                <p className="text-gray-600">Use the search bar above to find your favorite anime</p>
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">No anime found. Try refreshing the page.</p>
              </div>
            )}
          </>
        )}
      </main>

      {/* Anime Details Modal */}
      {selectedAnime && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <img
                src={selectedAnime.image}
                alt={selectedAnime.title}
                className="w-full h-64 object-cover rounded-t-xl"
              />
              <button
                onClick={() => setSelectedAnime(null)}
                className="absolute top-4 right-4 bg-black bg-opacity-50 text-white p-2 rounded-full hover:bg-opacity-75 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                {selectedAnime.titleEnglish || selectedAnime.title}
              </h2>
              
              {selectedAnime.title !== selectedAnime.titleEnglish && selectedAnime.titleEnglish && (
                <p className="text-gray-600 mb-4">{selectedAnime.title}</p>
              )}
              
              <div className="flex items-center gap-4 mb-4">
                {selectedAnime.score && (
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">Score:</span>
                    <span className="text-yellow-600">{selectedAnime.score}</span>
                  </div>
                )}
                
                {selectedAnime.episodes && (
                  <div>
                    <span className="font-semibold">Episodes:</span> {selectedAnime.episodes}
                  </div>
                )}
                
                <div>
                  <span className="font-semibold">Status:</span> {selectedAnime.status}
                </div>
              </div>
              
              {selectedAnime.synopsis && (
                <div className="mb-4">
                  <h3 className="font-semibold mb-2">Synopsis</h3>
                  <p className="text-gray-700">{selectedAnime.synopsis}</p>
                </div>
              )}
              
              {selectedAnime.genres && selectedAnime.genres.length > 0 && (
                <div className="mb-4">
                  <h3 className="font-semibold mb-2">Genres</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedAnime.genres.map((genre, index) => (
                      <span
                        key={index}
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                      >
                        {genre}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedAnime.studios && selectedAnime.studios.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Studios</h3>
                  <p className="text-gray-700">{selectedAnime.studios.join(', ')}</p>
                </div>
              )}
              
              {user && (
                <div className="mt-6 pt-6 border-t">
                  <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors mr-3">
                    Add to Watchlist
                  </button>
                  <button className="bg-gray-200 text-gray-800 px-6 py-2 rounded-lg hover:bg-gray-300 transition-colors">
                    Write Review
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;