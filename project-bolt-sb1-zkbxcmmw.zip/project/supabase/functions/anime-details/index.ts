/*
  # Anime Details Function

  This edge function fetches detailed information about a specific anime by its MAL ID.
  It includes caching in the anime_cache table for better performance.
*/

import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface JikanAnimeDetails {
  mal_id: number;
  url: string;
  images: {
    jpg: {
      image_url: string;
      small_image_url: string;
      large_image_url: string;
    };
  };
  title: string;
  title_english?: string;
  title_japanese?: string;
  synopsis?: string;
  episodes?: number;
  status: string;
  aired: {
    from?: string;
    to?: string;
  };
  score?: number;
  scored_by?: number;
  rank?: number;
  popularity?: number;
  genres: Array<{ mal_id: number; name: string }>;
  studios: Array<{ mal_id: number; name: string }>;
  producers: Array<{ mal_id: number; name: string }>;
  licensors: Array<{ mal_id: number; name: string }>;
  source: string;
  duration: string;
  rating: string;
  year?: number;
  season?: string;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const url = new URL(req.url);
    const malId = url.searchParams.get('mal_id');

    if (!malId) {
      return new Response(
        JSON.stringify({ error: 'mal_id parameter is required' }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Check if we have cached data (less than 24 hours old)
    const { data: cachedAnime } = await supabase
      .from('anime_cache')
      .select('*')
      .eq('mal_id', parseInt(malId))
      .gte('cached_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
      .single();

    if (cachedAnime) {
      // Return cached data
      const transformedData = {
        id: cachedAnime.mal_id,
        malId: cachedAnime.mal_id,
        title: cachedAnime.title,
        titleEnglish: cachedAnime.title_english,
        synopsis: cachedAnime.synopsis,
        image: cachedAnime.image_url,
        score: cachedAnime.score,
        episodes: cachedAnime.episodes,
        status: cachedAnime.status,
        airedFrom: cachedAnime.aired_from,
        airedTo: cachedAnime.aired_to,
        genres: cachedAnime.genres || [],
        studios: cachedAnime.studios || [],
      };

      return new Response(JSON.stringify(transformedData), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      });
    }

    // Fetch from Jikan API
    const jikanUrl = `https://api.jikan.moe/v4/anime/${malId}`;
    const response = await fetch(jikanUrl, {
      headers: {
        'User-Agent': 'AniTracker/1.0',
      },
    });

    if (!response.ok) {
      throw new Error(`Jikan API error: ${response.status} ${response.statusText}`);
    }

    const { data: anime }: { data: JikanAnimeDetails } = await response.json();

    // Cache the anime data
    await supabase
      .from('anime_cache')
      .upsert({
        mal_id: anime.mal_id,
        title: anime.title,
        title_english: anime.title_english,
        synopsis: anime.synopsis,
        image_url: anime.images.jpg.large_image_url || anime.images.jpg.image_url,
        score: anime.score,
        episodes: anime.episodes,
        status: anime.status,
        aired_from: anime.aired.from ? new Date(anime.aired.from).toISOString().split('T')[0] : null,
        aired_to: anime.aired.to ? new Date(anime.aired.to).toISOString().split('T')[0] : null,
        genres: anime.genres.map(g => g.name),
        studios: anime.studios.map(s => s.name),
        cached_at: new Date().toISOString(),
      });

    // Transform and return the data
    const transformedData = {
      id: anime.mal_id,
      malId: anime.mal_id,
      title: anime.title,
      titleEnglish: anime.title_english,
      synopsis: anime.synopsis,
      image: anime.images.jpg.large_image_url || anime.images.jpg.image_url,
      score: anime.score,
      episodes: anime.episodes,
      status: anime.status,
      airedFrom: anime.aired.from,
      airedTo: anime.aired.to,
      genres: anime.genres.map(g => g.name),
      studios: anime.studios.map(s => s.name),
      rank: anime.rank,
      popularity: anime.popularity,
      source: anime.source,
      duration: anime.duration,
      rating: anime.rating,
      year: anime.year,
      season: anime.season,
    };

    return new Response(JSON.stringify(transformedData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('Anime details error:', error);
    
    return new Response(
      JSON.stringify({
        error: 'Failed to fetch anime details',
        message: error instanceof Error ? error.message : 'Unknown error',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});