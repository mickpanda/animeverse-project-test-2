/*
  # Seasonal Anime Function

  This edge function fetches currently airing and upcoming seasonal anime.
  Perfect for discovering new releases and trending shows.
*/

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface JikanSeasonalResponse {
  data: Array<{
    mal_id: number;
    url: string;
    images: {
      jpg: {
        image_url: string;
        small_image_url: string;
        large_image_url: string;
      };
    };
    title: string;
    title_english?: string;
    synopsis?: string;
    episodes?: number;
    status: string;
    aired: {
      from?: string;
      to?: string;
    };
    score?: number;
    genres: Array<{ mal_id: number; name: string }>;
    studios: Array<{ mal_id: number; name: string }>;
    members: number;
    popularity: number;
  }>;
  pagination: {
    last_visible_page: number;
    has_next_page: boolean;
    current_page: number;
  };
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const url = new URL(req.url);
    const year = url.searchParams.get('year') || new Date().getFullYear().toString();
    const season = url.searchParams.get('season') || getCurrentSeason();
    const page = url.searchParams.get('page') || '1';

    // Build Jikan API URL for seasonal anime
    const jikanUrl = `https://api.jikan.moe/v4/seasons/${year}/${season}?page=${page}`;

    // Fetch from Jikan API
    const response = await fetch(jikanUrl, {
      headers: {
        'User-Agent': 'AniTracker/1.0',
      },
    });

    if (!response.ok) {
      throw new Error(`Jikan API error: ${response.status} ${response.statusText}`);
    }

    const data: JikanSeasonalResponse = await response.json();

    // Transform the data
    const transformedData = {
      anime: data.data.map(anime => ({
        id: anime.mal_id,
        malId: anime.mal_id,
        title: anime.title,
        titleEnglish: anime.title_english,
        synopsis: anime.synopsis,
        image: anime.images.jpg.large_image_url || anime.images.jpg.image_url,
        score: anime.score,
        episodes: anime.episodes,
        status: anime.status,
        airedFrom: anime.aired.from,
        airedTo: anime.aired.to,
        genres: anime.genres.map(g => g.name),
        studios: anime.studios.map(s => s.name),
        members: anime.members,
        popularity: anime.popularity,
      })),
      pagination: {
        currentPage: data.pagination.current_page,
        hasNextPage: data.pagination.has_next_page,
        lastPage: data.pagination.last_visible_page,
      },
      season: {
        year: parseInt(year),
        season: season,
      },
    };

    return new Response(JSON.stringify(transformedData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('Seasonal anime error:', error);
    
    return new Response(
      JSON.stringify({
        error: 'Failed to fetch seasonal anime',
        message: error instanceof Error ? error.message : 'Unknown error',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

// Helper function to get current season
function getCurrentSeason(): string {
  const month = new Date().getMonth() + 1; // getMonth() returns 0-11
  
  if (month >= 3 && month <= 5) return 'spring';
  if (month >= 6 && month <= 8) return 'summer';
  if (month >= 9 && month <= 11) return 'fall';
  return 'winter';
}