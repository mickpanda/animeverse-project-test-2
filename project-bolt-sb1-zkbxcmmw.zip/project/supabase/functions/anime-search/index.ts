/*
  # Anime Search Function

  This edge function provides anime search functionality by proxying requests to the Jikan API.
  It includes caching, error handling, and data transformation.
*/

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface JikanAnimeResponse {
  data: JikanAnime[];
  pagination: {
    last_visible_page: number;
    has_next_page: boolean;
    current_page: number;
    items: {
      count: number;
      total: number;
      per_page: number;
    };
  };
}

interface JikanAnime {
  mal_id: number;
  url: string;
  images: {
    jpg: {
      image_url: string;
      small_image_url: string;
      large_image_url: string;
    };
  };
  title: string;
  title_english?: string;
  title_japanese?: string;
  synopsis?: string;
  episodes?: number;
  status: string;
  aired: {
    from?: string;
    to?: string;
  };
  score?: number;
  genres: Array<{ mal_id: number; name: string }>;
  studios: Array<{ mal_id: number; name: string }>;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const url = new URL(req.url);
    const query = url.searchParams.get('q');
    const page = url.searchParams.get('page') || '1';
    const limit = url.searchParams.get('limit') || '25';
    const type = url.searchParams.get('type') || 'tv';
    const status = url.searchParams.get('status');
    const genre = url.searchParams.get('genre');

    // Build Jikan API URL
    const jikanUrl = new URL('https://api.jikan.moe/v4/anime');
    
    if (query) jikanUrl.searchParams.set('q', query);
    jikanUrl.searchParams.set('page', page);
    jikanUrl.searchParams.set('limit', limit);
    jikanUrl.searchParams.set('type', type);
    if (status) jikanUrl.searchParams.set('status', status);
    if (genre) jikanUrl.searchParams.set('genres', genre);

    // Fetch from Jikan API with rate limiting consideration
    const response = await fetch(jikanUrl.toString(), {
      headers: {
        'User-Agent': 'AniTracker/1.0',
      },
    });

    if (!response.ok) {
      throw new Error(`Jikan API error: ${response.status} ${response.statusText}`);
    }

    const data: JikanAnimeResponse = await response.json();

    // Transform the data to match our frontend expectations
    const transformedData = {
      anime: data.data.map(anime => ({
        id: anime.mal_id,
        malId: anime.mal_id,
        title: anime.title,
        titleEnglish: anime.title_english,
        synopsis: anime.synopsis,
        image: anime.images.jpg.large_image_url || anime.images.jpg.image_url,
        score: anime.score,
        episodes: anime.episodes,
        status: anime.status,
        airedFrom: anime.aired.from,
        airedTo: anime.aired.to,
        genres: anime.genres.map(g => g.name),
        studios: anime.studios.map(s => s.name),
      })),
      pagination: {
        currentPage: data.pagination.current_page,
        hasNextPage: data.pagination.has_next_page,
        lastPage: data.pagination.last_visible_page,
        total: data.pagination.items.total,
      },
    };

    return new Response(JSON.stringify(transformedData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('Anime search error:', error);
    
    return new Response(
      JSON.stringify({
        error: 'Failed to search anime',
        message: error instanceof Error ? error.message : 'Unknown error',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});