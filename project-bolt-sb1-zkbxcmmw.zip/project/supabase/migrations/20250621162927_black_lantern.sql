/*
  # Anime Tracking Platform Database Schema

  1. New Tables
    - `user_profiles`
      - `id` (uuid, primary key, references auth.users)
      - `username` (text, unique)
      - `avatar_url` (text)
      - `bio` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `anime_cache`
      - `id` (uuid, primary key)
      - `mal_id` (integer, unique, MyAnimeList ID)
      - `title` (text)
      - `title_english` (text)
      - `synopsis` (text)
      - `image_url` (text)
      - `score` (decimal)
      - `episodes` (integer)
      - `status` (text)
      - `aired_from` (date)
      - `aired_to` (date)
      - `genres` (jsonb)
      - `studios` (jsonb)
      - `cached_at` (timestamp)
      - `created_at` (timestamp)
    
    - `user_watchlist`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `anime_mal_id` (integer)
      - `status` (text) -- watching, completed, plan_to_watch, dropped, on_hold
      - `rating` (integer, 1-10)
      - `episodes_watched` (integer)
      - `notes` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `user_reviews`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `anime_mal_id` (integer)
      - `rating` (integer, 1-10)
      - `review_text` (text)
      - `is_spoiler` (boolean)
      - `helpful_count` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `forum_posts`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `anime_mal_id` (integer, optional)
      - `title` (text)
      - `content` (text)
      - `category` (text) -- discussion, recommendation, news, etc.
      - `reply_count` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `forum_replies`
      - `id` (uuid, primary key)
      - `post_id` (uuid, references forum_posts)
      - `user_id` (uuid, references user_profiles)
      - `content` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add policies for public read access where appropriate

  3. Indexes
    - Add indexes for frequently queried columns
    - Add composite indexes for common query patterns
*/

-- Create user profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  avatar_url text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create anime cache table
CREATE TABLE IF NOT EXISTS anime_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mal_id integer UNIQUE NOT NULL,
  title text NOT NULL,
  title_english text,
  synopsis text,
  image_url text,
  score decimal(3,2),
  episodes integer,
  status text,
  aired_from date,
  aired_to date,
  genres jsonb DEFAULT '[]',
  studios jsonb DEFAULT '[]',
  cached_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create user watchlist table
CREATE TABLE IF NOT EXISTS user_watchlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  anime_mal_id integer NOT NULL,
  status text NOT NULL DEFAULT 'plan_to_watch',
  rating integer CHECK (rating >= 1 AND rating <= 10),
  episodes_watched integer DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, anime_mal_id)
);

-- Create user reviews table
CREATE TABLE IF NOT EXISTS user_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  anime_mal_id integer NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 10),
  review_text text NOT NULL,
  is_spoiler boolean DEFAULT false,
  helpful_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, anime_mal_id)
);

-- Create forum posts table
CREATE TABLE IF NOT EXISTS forum_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  anime_mal_id integer,
  title text NOT NULL,
  content text NOT NULL,
  category text NOT NULL DEFAULT 'discussion',
  reply_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create forum replies table
CREATE TABLE IF NOT EXISTS forum_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE anime_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_watchlist ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_replies ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_profiles
CREATE POLICY "Users can view all profiles" ON user_profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can update own profile" ON user_profiles FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON user_profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- RLS Policies for anime_cache (public read, no user writes)
CREATE POLICY "Anyone can view anime cache" ON anime_cache FOR SELECT TO authenticated USING (true);

-- RLS Policies for user_watchlist
CREATE POLICY "Users can view own watchlist" ON user_watchlist FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert to own watchlist" ON user_watchlist FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own watchlist" ON user_watchlist FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own watchlist items" ON user_watchlist FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for user_reviews
CREATE POLICY "Anyone can view reviews" ON user_reviews FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert own reviews" ON user_reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own reviews" ON user_reviews FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own reviews" ON user_reviews FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for forum_posts
CREATE POLICY "Anyone can view posts" ON forum_posts FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert own posts" ON forum_posts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own posts" ON forum_posts FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own posts" ON forum_posts FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for forum_replies
CREATE POLICY "Anyone can view replies" ON forum_replies FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert own replies" ON forum_replies FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own replies" ON forum_replies FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own replies" ON forum_replies FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_anime_cache_mal_id ON anime_cache(mal_id);
CREATE INDEX IF NOT EXISTS idx_anime_cache_title ON anime_cache USING gin(to_tsvector('english', title));
CREATE INDEX IF NOT EXISTS idx_user_watchlist_user_id ON user_watchlist(user_id);
CREATE INDEX IF NOT EXISTS idx_user_watchlist_anime_mal_id ON user_watchlist(anime_mal_id);
CREATE INDEX IF NOT EXISTS idx_user_watchlist_status ON user_watchlist(status);
CREATE INDEX IF NOT EXISTS idx_user_reviews_anime_mal_id ON user_reviews(anime_mal_id);
CREATE INDEX IF NOT EXISTS idx_forum_posts_category ON forum_posts(category);
CREATE INDEX IF NOT EXISTS idx_forum_posts_anime_mal_id ON forum_posts(anime_mal_id);
CREATE INDEX IF NOT EXISTS idx_forum_replies_post_id ON forum_replies(post_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_user_watchlist_updated_at BEFORE UPDATE ON user_watchlist FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_user_reviews_updated_at BEFORE UPDATE ON user_reviews FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_forum_posts_updated_at BEFORE UPDATE ON forum_posts FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Function to increment reply count on forum posts
CREATE OR REPLACE FUNCTION increment_reply_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE forum_posts 
  SET reply_count = reply_count + 1 
  WHERE id = NEW.post_id;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for reply count
CREATE TRIGGER increment_forum_reply_count AFTER INSERT ON forum_replies FOR EACH ROW EXECUTE PROCEDURE increment_reply_count();